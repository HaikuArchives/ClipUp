#if DEBUG
#include <iostream>
#endif

#include "DeskbarView.h"

int main()
{
	DeskbarView::AddToDeskbar();
	return 0;
}
